let caminhaoX = -150;
let estado = 'indo';
let tempoDescarregando = 0;
let alimentosNoMercado = 0;

function setup() {
  createCanvas(800, 400);
  frameRate(60);
}

function draw() {
  background(135, 206, 235); // céu

  desenharSol();
  desenharPassaros();
  desenharGrama();
  desenharArvores();
  desenharCidade();
  desenharMercado();
  desenharCaminhao(caminhaoX, 330);

  // Controle de estados
  if (estado === 'indo') {
    caminhaoX += 2;
    if (caminhaoX >= 600) {
      estado = 'descarregando';
      tempoDescarregando = frameCount;
    }
  } else if (estado === 'descarregando') {
    if (frameCount - tempoDescarregando > 60) {
      alimentosNoMercado += 3;
      estado = 'saindo';
    }
  } else if (estado === 'saindo') {
    caminhaoX += 2;
    if (caminhaoX > width + 150) {
      estado = 'retornando';
      caminhaoX = -150;
    }
  } else if (estado === 'retornando') {
    caminhaoX += 2;
    if (caminhaoX >= 0) {
      // Caminhão voltou ao campo → reinicia o jogo
      estado = 'indo';
      alimentosNoMercado = 0;
      caminhaoX = -150;
    }
  }
}

// === FUNÇÕES VISUAIS ===

function desenharSol() {
  fill(255, 204, 0);
  noStroke();
  ellipse(700, 80, 80, 80);
}

function desenharPassaros() {
  stroke(0);
  noFill();
  for (let i = 0; i < 3; i++) {
    let x = 100 + i * 60;
    let y = 100 - i * 10;
    arc(x, y, 20, 10, PI, TWO_PI);
    arc(x + 20, y, 20, 10, PI, TWO_PI);
  }
}

function desenharGrama() {
  noStroke();
  fill(34, 139, 34);
  rect(0, 350, width, 50);
}

function desenharArvores() {
  for (let i = 50; i < 400; i += 100) {
    fill(139, 69, 19);
    rect(i, 280, 20, 70);
    fill(34, 139, 34);
    ellipse(i + 10, 260, 60, 60);
  }
}

function desenharCidade() {
  for (let i = 600; i < 800; i += 40) {
    fill(169, 169, 169);
    rect(i, 200, 30, 150);
    fill(255);
    for (let y = 210; y < 330; y += 20) {
      rect(i + 5, y, 5, 10);
    }
  }

  fill(105, 105, 105, 100);
  for (let i = 620; i < 800; i += 60) {
    ellipse(i, 180, 30, 30);
    ellipse(i + 10, 160, 20, 20);
    ellipse(i + 20, 140, 15, 15);
  }

  fill(255, 200, 200);
  rect(560, 280, 30, 70);
  triangle(555, 280, 575, 250, 595, 280);
  
  fill(0);
  rect(650, 340, 40, 20);
  fill(255);
  ellipse(660, 360, 10, 10);
  ellipse(680, 360, 10, 10);
}

function desenharMercado() {
  fill(200, 100, 100);
  rect(610, 320, 60, 30);
  fill(255);
  textSize(10);
  text("Mercado", 615, 340);

  fill(255, 255, 0);
  for (let i = 0; i < alimentosNoMercado; i++) {
    let x = 615 + (i % 3) * 15;
    let y = 310 - floor(i / 3) * 10;
    ellipse(x, y, 10, 10);
  }
}

function desenharCaminhao(x, y) {
  fill(255, 0, 0);
  rect(x, y - 20, 100, 40);
  fill(150);
  rect(x + 100, y - 40, 40, 60);

  fill(0);
  ellipse(x + 20, y + 20, 20, 20);
  ellipse(x + 120, y + 20, 20, 20);

  // Alimentos só se estiver indo
  if (estado === 'indo') {
    fill(255, 255, 0);
    ellipse(x + 30, y - 10, 10, 10);
    ellipse(x + 50, y - 10, 10, 10);
    ellipse(x + 70, y - 10, 10, 10);
  }

  // Fazendeiro
  fill(255, 220, 185);
  ellipse(x + 115, y - 20, 15, 15);
  fill(0);
  rect(x + 108, y - 10, 15, 5);
}
